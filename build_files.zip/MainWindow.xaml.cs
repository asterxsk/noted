﻿using Noted.Services;
using Noted.ViewModels;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Threading.Tasks;
using System;
using System.Linq;

namespace Noted
{
    public partial class MainWindow : Window
    {
        private readonly MainViewModel _viewModel;
        private double _currentZoom = 1.0;

        public MainWindow()
        {
            InitializeComponent();
            
            // Manual Dependency Injection
            var fileService = new FileService();
            _viewModel = new MainViewModel(fileService);
            DataContext = _viewModel;
            
            // Subscribe to notification events
            _viewModel.RequestNotification += (s, message) => ShowNotification(message);

            // Auto-focus text box
            Loaded += (s, e) => MainRichTextBox.Focus();
        }

        public void LoadFile(string path)
        {
            _viewModel.LoadFile(path);
        }

        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!_viewModel.ConfirmUnsavedChanges())
            {
                e.Cancel = true;
            }
        }

        private void Undo_Click(object sender, RoutedEventArgs e)
        {
            MainRichTextBox.Undo();
        }

        private void Redo_Click(object sender, RoutedEventArgs e)
        {
            MainRichTextBox.Redo();
        }

        private void ZoomIn_Click(object sender, RoutedEventArgs e)
        {
            if (_viewModel.ZoomInCommand.CanExecute(null))
                _viewModel.ZoomInCommand.Execute(null);
        }

        private void ZoomOut_Click(object sender, RoutedEventArgs e)
        {
            if (_viewModel.ZoomOutCommand.CanExecute(null))
                _viewModel.ZoomOutCommand.Execute(null);
        }

        private void RestoreZoom_Click(object sender, RoutedEventArgs e)
        {
            if (_viewModel.RestoreDefaultZoomCommand.CanExecute(null))
                _viewModel.RestoreDefaultZoomCommand.Execute(null);
        }

        // List features
        private void BulletList_Click(object sender, RoutedEventArgs e)
        {
            EditingCommands.ToggleBullets.Execute(null, MainRichTextBox);
        }

        private void NumberedList_Click(object sender, RoutedEventArgs e)
        {
            EditingCommands.ToggleNumbering.Execute(null, MainRichTextBox);
        }

        private void Checklist_Click(object sender, RoutedEventArgs e)
        {
            // Get current selection
            var selection = MainRichTextBox.Selection;
            if (selection.IsEmpty)
                return;

            // Insert checkbox symbol at the start of each paragraph in selection
            var start = selection.Start.Paragraph ?? selection.Start.GetInsertionPosition(LogicalDirection.Forward).Paragraph;
            var end = selection.End.Paragraph ?? selection.End.GetInsertionPosition(LogicalDirection.Backward).Paragraph;

            if (start == null) return;

            var current = start;
            while (current != null)
            {
                var checkboxSymbol = "☐ "; // Unchecked checkbox
                var paragraphStart = current.ContentStart.GetInsertionPosition(LogicalDirection.Forward);
                
                if (paragraphStart != null)
                {
                    var text = new TextRange(paragraphStart, current.ContentEnd).Text;
                    
                    // Toggle: if already has checkbox, remove it; otherwise add it
                    if (text.StartsWith("☐ ") || text.StartsWith("☑ "))
                    {
                        // Remove checkbox
                        var endPos = paragraphStart.GetPositionAtOffset(2);
                        if (endPos != null)
                        {
                            new TextRange(paragraphStart, endPos).Text = "";
                        }
                    }
                    else
                    {
                        // Add checkbox
                        new TextRange(paragraphStart, paragraphStart).Text = checkboxSymbol;
                    }
                }

                if (current == end) break;
                current = current.NextBlock as Paragraph;
            }
        }

        private void RichTextBox_SelectionChanged(object sender, RoutedEventArgs e)
        {
            // Update status bar or other UI elements based on selection
            if (sender is RichTextBox richTextBox)
            {
                var selection = richTextBox.Selection;
                var pointer = selection.Start;
                var lineNumber = pointer.Paragraph != null ? 
                    richTextBox.Document.Blocks.ToList().IndexOf(pointer.Paragraph) + 1 : 1;
                var columnNumber = pointer.GetOffsetToPosition(pointer.GetLineStartPosition(0));
                
                _viewModel.StatusText = $"{_viewModel.FileName} | {( _viewModel.IsModified ? "Unsaved" : "Saved")} | Ln {lineNumber}, Col {Math.Abs(columnNumber)}";
            }
        }

        private void RichTextBox_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                if (e.Delta > 0)
                {
                    if (_viewModel.ZoomInCommand.CanExecute(null))
                        _viewModel.ZoomInCommand.Execute(null);
                }
                else
                {
                    if (_viewModel.ZoomOutCommand.CanExecute(null))
                        _viewModel.ZoomOutCommand.Execute(null);
                }
                e.Handled = true;
            }
        }

        private async void ShowNotification(string message)
        {
            NotificationText.Text = message;
            
            var fadeIn = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(200));
            NotificationPill.BeginAnimation(UIElement.OpacityProperty, fadeIn);

            await Task.Delay(3000);

            var fadeOut = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(200));
            NotificationPill.BeginAnimation(UIElement.OpacityProperty, fadeOut);
        }
    }
}