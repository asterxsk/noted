using Noted.Services;
using System.IO;

namespace Noted.ViewModels
{
    public class DocumentViewModel : ViewModelBase
    {
        private string _content;
        private string _filePath;
        private string _fileName;
        private bool _isModified;
        private string _statusText = "Ln 1, Col 1";

        public DocumentViewModel()
        {
            FileName = "Untitled";
            Content = string.Empty;
        }

        public string Content
        {
            get => _content;
            set
            {
                if (SetProperty(ref _content, value))
                {
                    IsModified = true;
                }
            }
        }

        public string FilePath
        {
            get => _filePath;
            set
            {
                if (SetProperty(ref _filePath, value))
                {
                    FileName = string.IsNullOrEmpty(value) ? "Untitled" : Path.GetFileName(value);
                    IsModified = false;
                }
            }
        }

        public string FileName
        {
            get => _fileName;
            set => SetProperty(ref _fileName, value);
        }

        public bool IsModified
        {
            get => _isModified;
            set => SetProperty(ref _isModified, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }
    }
}
