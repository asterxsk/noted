using Noted.Services;
using System;
using System.IO;
using System.Windows;
using System.Windows.Input;

namespace Noted.ViewModels
{
    public class MainViewModel : ViewModelBase
    {
        private readonly IFileService _fileService;
        private string _content;
        private string _filePath;
        private bool _isModified;
        private double _zoom = 1.0;
        private string _statusText = "Ready";

        public event EventHandler<string> RequestNotification;

        public MainViewModel(IFileService fileService)
        {
            _fileService = fileService;
            _content = string.Empty;
            
            NewCommand = new RelayCommand(_ => NewFile());
            OpenCommand = new RelayCommand(_ => OpenFile());
            SaveCommand = new RelayCommand(_ => SaveFile());
            SaveAsCommand = new RelayCommand(_ => SaveFileAs());
            ExitCommand = new RelayCommand(_ => Exit());
            ZoomInCommand = new RelayCommand(_ => Zoom += 0.1);
            ZoomOutCommand = new RelayCommand(_ => Zoom = Math.Max(0.1, Zoom - 0.1));
            RestoreDefaultZoomCommand = new RelayCommand(_ => Zoom = 1.0);

            UpdateStatus();
        }

        public string Content
        {
            get => _content;
            set
            {
                if (SetProperty(ref _content, value))
                {
                    IsModified = true;
                }
            }
        }

        public string FilePath
        {
            get => _filePath;
            set
            {
                if (SetProperty(ref _filePath, value))
                {
                    OnPropertyChanged(nameof(FileName));
                    OnPropertyChanged(nameof(Title));
                    UpdateStatus();
                }
            }
        }

        public string FileName => string.IsNullOrEmpty(FilePath) ? "Untitled" : Path.GetFileName(FilePath);

        public string Title => $"{FileName}{(IsModified ? "*" : "")} - Noted";

        public bool IsModified
        {
            get => _isModified;
            set
            {
                if (SetProperty(ref _isModified, value))
                {
                    OnPropertyChanged(nameof(Title));
                    UpdateStatus();
                }
            }
        }

        public double Zoom
        {
            get => _zoom;
            set => SetProperty(ref _zoom, value);
        }

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public ICommand NewCommand { get; }
        public ICommand OpenCommand { get; }
        public ICommand SaveCommand { get; }
        public ICommand SaveAsCommand { get; }
        public ICommand ExitCommand { get; }
        public ICommand ZoomInCommand { get; }
        public ICommand ZoomOutCommand { get; }
        public ICommand RestoreDefaultZoomCommand { get; }

        private void NewFile()
        {
            if (ConfirmUnsavedChanges())
            {
                Content = string.Empty;
                FilePath = null;
                IsModified = false;
                RequestNotification?.Invoke(this, "New file created");
            }
        }

        private void OpenFile()
        {
            if (ConfirmUnsavedChanges())
            {
                var (content, path) = _fileService.OpenFile();
                if (path != null)
                {
                    // Disable IsModified tracking while loading
                    _content = content;
                    OnPropertyChanged(nameof(Content));
                    
                    FilePath = path;
                    IsModified = false;
                    RequestNotification?.Invoke(this, "File opened");
                }
            }
        }

        public void LoadFile(string path)
        {
            if (ConfirmUnsavedChanges())
            {
                var content = _fileService.ReadFile(path);
                if (content != null)
                {
                    // Disable IsModified tracking while loading
                    _content = content;
                    OnPropertyChanged(nameof(Content));
                    
                    FilePath = path;
                    IsModified = false;
                    RequestNotification?.Invoke(this, "File opened");
                }
            }
        }

        private void SaveFile()
        {
            if (string.IsNullOrEmpty(FilePath))
            {
                SaveFileAs();
            }
            else
            {
                if (_fileService.SaveFile(FilePath, Content))
                {
                    IsModified = false;
                    RequestNotification?.Invoke(this, "File saved");
                }
            }
        }

        private void SaveFileAs()
        {
            var path = _fileService.SaveFileAs(Content, FilePath);
            if (path != null)
            {
                FilePath = path;
                IsModified = false;
                RequestNotification?.Invoke(this, "File saved");
            }
        }

        public bool ConfirmUnsavedChanges()
        {
            if (IsModified)
            {
                var dialog = new ConfirmationDialog($"Do you want to save changes to {FileName}?");
                dialog.Owner = Application.Current.MainWindow;
                dialog.ShowDialog();
                
                var result = dialog.Result;

                if (result == MessageBoxResult.Yes)
                {
                    SaveFile();
                    return !IsModified; // Return true if save was successful (IsModified became false)
                }
                return result == MessageBoxResult.No;
            }
            return true;
        }

        private void Exit()
        {
            if (ConfirmUnsavedChanges())
            {
                Application.Current.Shutdown();
            }
        }

        private void UpdateStatus()
        {
            StatusText = $"{FileName} | {(IsModified ? "Unsaved" : "Saved")}";
        }
    }
}
