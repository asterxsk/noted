using Microsoft.Win32;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Documents;

namespace Noted.Services
{
    public class FileService : IFileService
    {
        public (string content, string filePath) OpenFile()
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "All Text Files|*.txt;*.rtf;*.log;*.md;*.json;*.xml;*.html;*.css;*.js;*.ts;*.py;*.java;*.c;*.cpp;*.h;*.cs;*.vb;*.sql;*.sh;*.bat;*.ps1;*.php;*.rb;*.go;*.rs;*.swift;*.kt;*.dart|" +
                         "Text files (*.txt)|*.txt|" +
                         "Rich Text Format (*.rtf)|*.rtf|" +
                         "Log files (*.log)|*.log|" +
                         "Code files|*.js;*.ts;*.py;*.java;*.c;*.cpp;*.h;*.cs;*.vb;*.php;*.rb;*.go;*.rs;*.swift;*.kt;*.dart|" +
                         "Web files|*.html;*.css;*.xml;*.json|" +
                         "All files (*.*)|*.*",
                FilterIndex = 1 // Default to all text files
            };

            if (openFileDialog.ShowDialog() == true)
            {
                var path = openFileDialog.FileName;
                return (File.ReadAllText(path), path);
            }

            return (null, null);
        }

        public string ReadFile(string path)
        {
            if (File.Exists(path))
            {
                return File.ReadAllText(path);
            }
            return null;
        }

        public bool SaveFile(string filePath, string content)
        {
            if (string.IsNullOrEmpty(filePath))
            {
                return false;
            }

            try
            {
                // Check if it's a .txt file, if so, extract plain text from RTF
                if (filePath.EndsWith(".txt", System.StringComparison.OrdinalIgnoreCase))
                {
                    var plainText = ExtractPlainTextFromRtf(content);
                    File.WriteAllText(filePath, plainText);
                }
                else
                {
                    File.WriteAllText(filePath, content);
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public string SaveFileAs(string content, string defaultPath = null)
        {
            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Text files (*.txt)|*.txt|" +
                         "Rich Text Format (*.rtf)|*.rtf|" +
                         "Log files (*.log)|*.log|" +
                         "All files (*.*)|*.*",
                FilterIndex = 1 // Default to .txt
            };

            if (!string.IsNullOrEmpty(defaultPath))
            {
                saveFileDialog.FileName = Path.GetFileName(defaultPath);
                saveFileDialog.InitialDirectory = Path.GetDirectoryName(defaultPath);
            }

            if (saveFileDialog.ShowDialog() == true)
            {
                var path = saveFileDialog.FileName;
                
                // Check if it's a .txt file, if so, extract plain text from RTF
                if (path.EndsWith(".txt", System.StringComparison.OrdinalIgnoreCase))
                {
                    var plainText = ExtractPlainTextFromRtf(content);
                    File.WriteAllText(path, plainText);
                }
                else
                {
                    File.WriteAllText(path, content);
                }
                return path;
            }

            return null;
        }

        private string ExtractPlainTextFromRtf(string rtfContent)
        {
            // If the content starts with RTF markup, extract plain text
            if (rtfContent != null && rtfContent.StartsWith("{\\rtf"))
            {
                try
                {
                    var rtfDoc = new FlowDocument();
                    var range = new TextRange(rtfDoc.ContentStart, rtfDoc.ContentEnd);
                    using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(rtfContent)))
                    {
                        range.Load(stream, System.Windows.DataFormats.Rtf);
                    }
                    return range.Text;
                }
                catch
                {
                    // If RTF parsing fails, return the content as-is
                    return rtfContent;
                }
            }
            return rtfContent; // Already plain text
        }
    }
}
