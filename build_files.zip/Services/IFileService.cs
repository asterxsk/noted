namespace Noted.Services
{
    public interface IFileService
    {
        (string content, string filePath) OpenFile();
        string ReadFile(string path);
        bool SaveFile(string filePath, string content);
        string SaveFileAs(string content, string defaultPath = null);
    }
}
