using System;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Threading;

namespace Noted.Helpers
{
    public class RichTextBoxHelper
    {
        public static readonly DependencyProperty DocumentContentProperty =
            DependencyProperty.RegisterAttached("DocumentContent", typeof(string), typeof(RichTextBoxHelper),
                new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnDocumentContentChanged));

        public static string GetDocumentContent(DependencyObject obj) => (string)obj.GetValue(DocumentContentProperty);
        public static void SetDocumentContent(DependencyObject obj, string value) => obj.SetValue(DocumentContentProperty, value);

        private static readonly DependencyProperty IsUpdatingProperty =
            DependencyProperty.RegisterAttached("IsUpdating", typeof(bool), typeof(RichTextBoxHelper), new PropertyMetadata(false));

        private static bool GetIsUpdating(DependencyObject obj) => (bool)obj.GetValue(IsUpdatingProperty);
        private static void SetIsUpdating(DependencyObject obj, bool value) => obj.SetValue(IsUpdatingProperty, value);

        private static readonly DependencyProperty LastLoadedContentProperty =
            DependencyProperty.RegisterAttached("LastLoadedContent", typeof(string), typeof(RichTextBoxHelper), new PropertyMetadata(null));

        private static string GetLastLoadedContent(DependencyObject obj) => (string)obj.GetValue(LastLoadedContentProperty);
        private static void SetLastLoadedContent(DependencyObject obj, string value) => obj.SetValue(LastLoadedContentProperty, value);

        private static readonly DependencyProperty UpdateTimerProperty =
            DependencyProperty.RegisterAttached("UpdateTimer", typeof(DispatcherTimer), typeof(RichTextBoxHelper), new PropertyMetadata(null));

        private static DispatcherTimer GetUpdateTimer(DependencyObject obj) => (DispatcherTimer)obj.GetValue(UpdateTimerProperty);
        private static void SetUpdateTimer(DependencyObject obj, DispatcherTimer value) => obj.SetValue(UpdateTimerProperty, value);

        private static void OnDocumentContentChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var richTextBox = d as RichTextBox;
            if (richTextBox == null) return;

            if (GetIsUpdating(richTextBox)) return;

            var newContent = (string)e.NewValue;
            var lastContent = GetLastLoadedContent(richTextBox);

            if (string.Equals(newContent, lastContent, StringComparison.Ordinal)) return;

            SetIsUpdating(richTextBox, true);
            try
            {
                richTextBox.TextChanged -= RichTextBox_TextChanged;

                var range = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
                
                if (!string.IsNullOrEmpty(newContent))
                {
                    using (var stream = new MemoryStream(Encoding.UTF8.GetBytes(newContent)))
                    {
                        if (newContent.StartsWith("{\\rtf"))
                        {
                            try
                            {
                                range.Load(stream, DataFormats.Rtf);
                            }
                            catch
                            {
                                stream.Position = 0;
                                range.Load(stream, DataFormats.Text);
                            }
                        }
                        else
                        {
                            range.Load(stream, DataFormats.Text);
                        }
                    }
                }
                else
                {
                    richTextBox.Document.Blocks.Clear();
                }
                
                SetLastLoadedContent(richTextBox, newContent);
                
                richTextBox.TextChanged += RichTextBox_TextChanged;
            }
            finally
            {
                SetIsUpdating(richTextBox, false);
            }
        }

        private static void RichTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var richTextBox = sender as RichTextBox;
            if (richTextBox == null) return;

            if (GetIsUpdating(richTextBox)) return;

            var timer = GetUpdateTimer(richTextBox);
            if (timer == null)
            {
                timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(50) };
                timer.Tick += (s, args) =>
                {
                    var t = s as DispatcherTimer;
                    t.Stop();
                    UpdateSource(richTextBox);
                };
                SetUpdateTimer(richTextBox, timer);
            }

            timer.Stop();
            timer.Start();
        }

        private static void UpdateSource(RichTextBox richTextBox)
        {
            if (GetIsUpdating(richTextBox)) return;

            SetIsUpdating(richTextBox, true);
            try
            {
                var range = new TextRange(richTextBox.Document.ContentStart, richTextBox.Document.ContentEnd);
                string content;
                using (var stream = new MemoryStream())
                {
                    range.Save(stream, DataFormats.Rtf);
                    content = Encoding.UTF8.GetString(stream.ToArray());
                }

                SetLastLoadedContent(richTextBox, content);
                SetDocumentContent(richTextBox, content);
            }
            finally
            {
                SetIsUpdating(richTextBox, false);
            }
        }

        public static readonly DependencyProperty IsWordWrapEnabledProperty =
            DependencyProperty.RegisterAttached("IsWordWrapEnabled", typeof(bool), typeof(RichTextBoxHelper),
                new PropertyMetadata(true, OnIsWordWrapEnabledChanged));

        public static bool GetIsWordWrapEnabled(DependencyObject obj) => (bool)obj.GetValue(IsWordWrapEnabledProperty);
        public static void SetIsWordWrapEnabled(DependencyObject obj, bool value) => obj.SetValue(IsWordWrapEnabledProperty, value);

        private static void OnIsWordWrapEnabledChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (d is RichTextBox richTextBox)
            {
                bool isEnabled = (bool)e.NewValue;
                richTextBox.Document.PageWidth = isEnabled ? double.NaN : 10000;
            }
        }
    }
}
