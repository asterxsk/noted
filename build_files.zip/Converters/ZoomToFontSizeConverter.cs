using System;
using System.Globalization;
using System.Windows.Data;

namespace Noted.Converters
{
    public class ZoomToFontSizeConverter : IValueConverter
    {
        private const double BaseFontSize = 14.0;

        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double zoom)
            {
                return BaseFontSize * zoom;
            }
            return BaseFontSize;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
